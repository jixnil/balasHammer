import React from "react";
import { getRowChar } from "./SharedUIHelpers";
import "./style/balas‑hammer.css";

export default function SteppingStoneDeltaTable({ step, cols, rows, savedCosts }) {
  const alloc = step.allocations;
  const deltaMatrix = Array.from({ length: rows }, () => Array(cols).fill(null));

  // Remplir la matrice des Δ
  (step.deltas || []).forEach(({ cell: [i, j], delta }) => {
    deltaMatrix[i][j] = delta;
  });

  // Fonctions d’aide
  const pathIndex = (i, j) =>
    (step.bestPath || []).findIndex(([pi, pj]) => pi === i && pj === j);

  const cellClass = (i, j) => {
    const cls = [];
    const p = pathIndex(i, j);
    if (p >= 0) cls.push(p % 2 === 0 ? "path-plus" : "path-minus");
    if (deltaMatrix[i][j] !== null && deltaMatrix[i][j] < 0) cls.push("delta-negative");
    if (step.bestCell && step.bestCell[0] === i && step.bestCell[1] === j) cls.push("best-delta-cell");
    return cls.join(" ");
  };

  return (
    <div className="bh-step-container">
  {/* === TABLE GRILLE PRINCIPALE === */}
  <table className="ss-table">
    <thead>
      <tr>
        <th></th>
        {Array.from({ length: cols }, (_, j) => (
          <th key={`h${j}`} className="ss-label">{j + 1}</th>
        ))}
        <th className="ss-label">Vy</th>
      </tr>
    </thead>

    <tbody>
      {Array.from({ length: rows }, (_, i) => (
        <tr key={`r${i}`}>
          {/* Label ligne A,B,C… */}
          <th className="ss-label">{getRowChar(i)}</th>

          {/* Cellules coût / allocation */}
          {Array.from({ length: cols }, (_, j) => {
            const cost  = (savedCosts ?? step.costs)[i][j];  // assume tu passes costs dans step
            const alloc = alloc[i][j];
            return (
              <td key={`c${i}-${j}`}
                  className={`${cellClass(i,j)}`}>
                <div className="ss-cost">{cost}</div>
                {alloc && (
                  <div className="ss-alloc">
                    {alloc === "ε" ? "ε" : alloc}
                  </div>
                )}
                {/* Affichage δ éventuel */}
                {deltaMatrix[i][j] !== null && (
                  <div className="delta-val">
                    δ={deltaMatrix[i][j]}
                  </div>
                )}
              </td>
            );
          })}

          {/* Offre restante */}
          <td className="ss-offer">{step.offer[i]}</td>
        </tr>
      ))}

      {/* Demande restante */}
      <tr>
        <th className="ss-label">Vx</th>
        {Array.from({ length: cols }, (_, j) => (
          <td key={`d${j}`} className="ss-demand">{step.demand[j]}</td>
        ))}
        <td></td>
      </tr>
    </tbody>
  </table>

  {/* === LISTE DES δ & FORMULE Z === */}
  <div className="ss-delta-list">
    {step.deltas?.map((d,idx) => (
      <p key={idx} className={d.delta < 0 ? "delta-negative-text": ""}>
        {d.formula}
      </p>
    ))}
  </div>

  {/* Formule Z */}
  {step.totalCost !== undefined && (
    <div className="z-formula">
      Z = {step.previousCost} {step.stepDelta>=0?'+':''}{step.stepDelta} =
      <span className="z-final"> {step.totalCost}</span>
    </div>
  )}
</div>

  );
}
