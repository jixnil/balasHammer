import BalasHammerApp from "./balasHammerAppFinal";

export default function App() {
  return <BalasHammerApp />;
}
