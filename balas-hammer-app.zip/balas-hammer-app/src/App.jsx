import BalasHammerApp from "./BalasHammerApp";

export default function App() {
  return <BalasHammerApp />;
}
